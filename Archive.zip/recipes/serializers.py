from rest_framework import serializers
from recipes.models import RecipePost

class RecipeSerializer(serializers.ModelSerializer):
    author = serializers.ReadOnlyField(source='author.username')

    class Meta:
        model = RecipePost
        fields = [
            'id', 'author', 'title', 'description', 
            'ingredients', 'category', 'created_at',
            'cook_time_minutes'
        ]
        read_only_fields = ['id', 'author', 'created_at']