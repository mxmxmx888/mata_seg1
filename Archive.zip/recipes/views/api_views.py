from rest_framework import generics, filters, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

from recipes.models import Notification, RecipePost
from recipes.serializers import RecipeSerializer
from recipes.permissions import IsOwnerOrReadOnly

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile_api(request):
    """
    Simple protected endpoint to test Firebase auth.
    Returns the Django user linked to the Firebase token.
    """
    user = request.user
    return Response({
        "uid": user.username,
        "email": user.email,
    })

@login_required
def mark_notifications_read(request):
    Notification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)
    return JsonResponse({'status': 'success'})

class RecipeListApi(generics.ListCreateAPIView):
    serializer_class = RecipeSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    # FIXED: Changed 'ingredients' to 'ingredients__name' to fix FieldError
    search_fields = ['title', 'description', 'ingredients__name', 'category']
    ordering_fields = ['average_rating', 'created_at']

    def get_queryset(self):
        """
        Optionally restricts the returned recipes by filtering
        against a `category` or `ingredient` query parameter in the URL.
        """
        queryset = RecipePost.objects.all()
        category = self.request.query_params.get('category')
        ingredient = self.request.query_params.get('ingredient')
        search = self.request.query_params.get('search')

        if category:
            queryset = queryset.filter(category__iexact=category)
        if ingredient:
            # FIXED: Use ingredients__name instead of raw ingredients field
            queryset = queryset.filter(ingredients__name__icontains=ingredient)
        if search:
            # SearchFilter backend handles this, but if you keep custom logic:
            queryset = queryset.filter(title__icontains=search)
            
        return queryset

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

class RecipeDetailApi(generics.RetrieveUpdateDestroyAPIView):
    queryset = RecipePost.objects.all()
    serializer_class = RecipeSerializer
    permission_classes = [IsOwnerOrReadOnly]